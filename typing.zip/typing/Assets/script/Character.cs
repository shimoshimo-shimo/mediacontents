using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        float speed = 360.0f;

        transform.rotation = Quaternion.Euler(0, 0, speed * Time.time);

        float amp = 2.0f;
        transform.position = new Vector3(Mathf.Sin(Mathf.PI * Time.time * 2.0f) * amp, 0.0f, 0.0f);
        transform.localScale = new Vector3(2.0f + Mathf.Sin(Mathf.PI * Time.time * 2.0f), 1.0f, 1.0f);

    }
}
