using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//�e�L�X�g�̕����ύX
public class typing : MonoBehaviour
{

    //��ʂɂ���e�L�X�g�������Ă���
    [SerializeField] Text m1Text; //���������P
    [SerializeField] Text m2Text; //���������Q
    [SerializeField] Text m3Text; //���������R
    [SerializeField] Text m4Text; //�����O���P
    [SerializeField] Text m5Text; //�����O���Q
    [SerializeField] Text m6Text; //�����O���R
    [SerializeField] Text m6Text;


    //���W
    private string[] _hatudou1 = { "1act", "1ice", "1mad", "1sue" };//3
    private string[] _hatudou2 = { "2abortion", "2covenant", "2supress", "2betrayal" };//8
    private string[] _hatudou3 = { "diversification", "3gastroenteritis", "3transfiguration" };//15

    //�ԍ��w��
    private string _h1string;
    private string _h2string;
    private string _h3string;

    private int _1qNum;
    private int _2qNum;
    private int _3qNum;

    private int _1aNum;
    private int _2aNum;
    private int _3aNum;


    // Start is called before the first frame update
    void Start()
    {
        OutPut();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(_h1string[_1aNum].ToString()))
        {

            //����
            _1aNum++;
            Debug.Log("����");

            if (_1aNum >= _h1string.Length)
            {
                OutPut();
            }
        }
        else if (Input.GetKeyDown(_h2string[_2aNum].ToString()))
        {

            //����
            _2aNum++;
            Debug.Log("����");

            if (_2aNum >= _h2string.Length)
            {
                OutPut();
            }
        }
        else if (Input.GetKeyDown(_h3string[_3aNum].ToString()))
        {

            //����
            _3aNum++;
            Debug.Log("����");

            if (_3aNum >= _h3string.Length)
            {
                OutPut();
            }
        }
        else if (Input.anyKeyDown)

            //���s
            Miss();
    }

    void OutPut()
    {
        _1aNum = 0;
        _2aNum = 0;
        _3aNum = 0;

        _1qNum = Random.Range(0, _hatudou1.Length);
        _2qNum = Random.Range(0, _hatudou2.Length);
        _3qNum = Random.Range(0, _hatudou3.Length);

        _h1string = _hatudou1[_1qNum];
        _h2string = _hatudou2[_2qNum];
        _h3string = _hatudou3[_3qNum];
        //�����ύX
        m1Text.text = _h1string;
        m2Text.text = _h2string;
        m3Text.text = _h3string;
    }

    //���������Ƃ�
    void Correct()
    {
        _1aNum++;
        _2aNum++;
        _3aNum++;
        Debug.Log("����");
    }

    //�ԈႦ���Ƃ�
    void Miss()
    {
        Debug.Log("�s����");
    }
}
